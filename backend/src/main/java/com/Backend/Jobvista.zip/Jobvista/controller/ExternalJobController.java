package com.Backend.Jobvista.controller;


import com.Backend.Jobvista.dto.Job.ExternalJobDTO;
import com.Backend.Jobvista.service.AdzunaService;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/external-jobs")
@AllArgsConstructor
public class ExternalJobController {

    private final AdzunaService adzunaService;

//    @GetMapping
//    public List<ExternalJobDTO> searchExternal(
//            @RequestParam String keyword,
//            @RequestParam(defaultValue = "1") int page) {
//
//        return adzunaService.searchJobs(keyword, page);
//    }

}
