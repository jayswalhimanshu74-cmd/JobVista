package com.Backend.Jobvista.event;


import com.Backend.Jobvista.entity.EmailType;
import com.Backend.Jobvista.utills.EmailService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@RequiredArgsConstructor
@Component
public class ApplicationEventListener {

    private final EmailService emailService;

    @EventListener
    public void handleApplicationEvent(ApplicationEvent event){

        emailService.sendMail(
                event.getEmail(),
                EmailType.APPLICATION_STATUS_UPDATED,
                Map.of(
                        "name", event.getName(),
                        "jobTitle", event.getJobTitle(),
                        "status", event.getStatus()
                )
        );

    }
}
