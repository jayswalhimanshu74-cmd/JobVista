    package com.Backend.Jobvista.service.impl;

    import com.Backend.Jobvista.dto.company.CompanyMapper;
    import com.Backend.Jobvista.dto.company.CompanyRequestDTO;
    import com.Backend.Jobvista.dto.company.CompanyResponseDTO;
    import com.Backend.Jobvista.entity.Company;
    import com.Backend.Jobvista.entity.Role;
    import com.Backend.Jobvista.entity.User;
    import com.Backend.Jobvista.repository.CompanyRepository;
    import com.Backend.Jobvista.repository.UserRepository;
    import com.Backend.Jobvista.service.CompanyService;
    import jakarta.transaction.Transactional;
    import lombok.AllArgsConstructor;
    import org.springframework.data.domain.Page;
    import org.springframework.data.domain.PageRequest;
    import org.springframework.data.domain.Pageable;
    import org.springframework.data.domain.Sort;
    import org.springframework.stereotype.Service;

    @Service
    @AllArgsConstructor
    public class CompanyServiceImplementation implements CompanyService {

        private final CompanyRepository companyRepository;
        private final UserRepository userRepository;


        @Override
        @Transactional
        public CompanyResponseDTO createCompany(CompanyRequestDTO dto, String email) {

            // 1. Get user
                User user = userRepository.findByEmail(email)
                        .orElseThrow(() -> new RuntimeException("User not found"));

            // 2. Check if already company
            if (companyRepository.existsByUser(user)) {
                throw new RuntimeException("Company already exists for this user");
            }
            // 3. Create company
                Company company = CompanyMapper.toEntity(dto, user);
            Company savedCompany = companyRepository.save(company);

            // 4. 🔥 UPGRADE ROLE
            user.setRole(Role.COMPANY);
            userRepository.save(user);

            return CompanyMapper.toResponse(companyRepository.save(company));
        }

        @Override
        public CompanyResponseDTO updateCompany(Long id, CompanyRequestDTO company) {
            Company existing = companyRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Company not found"));

            existing.setCompanyId(company.getUserId());
            existing.setCompanyName(company.getCompanyName());
            existing.setCompanyEmail(company.getCompanyEmail());
            existing.setDescription(company.getDescription());
            existing.setLocation(company.getLocation());
            existing.setLogoUrl(company.getLogoUrl());

            return CompanyMapper.toResponse(companyRepository.save(existing));
        }

        @Override
        public void deleteCompany(Long id) {

            Company company = companyRepository.findById(id).orElseThrow(()-> new RuntimeException("Invalid Company ID :" ));
            companyRepository.delete(company);
        }

        @Override
        public CompanyResponseDTO getCompanyById(Long id) {
            Company existing = companyRepository.findById(id).orElseThrow(()-> new RuntimeException("Invalid Company Id :"));
            return  CompanyMapper.toResponse(existing);
        }

        @Override
        public Page<CompanyResponseDTO> getAllCompanies(int page, int size) {

            Pageable pageable = PageRequest.of(page, size, Sort.by("companyName").ascending());

            Page<Company> companyPage = companyRepository.findAll(pageable);

            return companyPage.map(CompanyMapper::toResponse);
        }

        @Override
        public Page<CompanyResponseDTO> searchCompanies(String keyword, int page, int size) {

            Pageable pageable = PageRequest.of(page, size);

            Page<Company> companyPage =
                    companyRepository.findByCompanyNameContainingIgnoreCase(keyword, pageable);

            return companyPage.map(CompanyMapper::toResponse);
        }
    }
