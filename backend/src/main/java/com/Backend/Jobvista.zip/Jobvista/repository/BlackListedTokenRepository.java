package com.Backend.Jobvista.repository;

import com.Backend.Jobvista.entity.BlackListedToken;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.UUID;

public  interface BlackListedTokenRepository extends JpaRepository<BlackListedToken, UUID> {

    boolean existsByToken(String token);
    void deleteByExpiryDateBefore(Date date);
}
