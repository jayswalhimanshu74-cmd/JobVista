package com.Backend.Jobvista.event;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class ApplicationEvent {

    private String email;
    private String name;
    private String jobTitle;
    private String status;
}
